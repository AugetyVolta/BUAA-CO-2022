/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "E:/ISE_Programs/P5_Final/controller_IF.v";
static unsigned int ng1[] = {5U, 0U};
static unsigned int ng2[] = {1U, 0U};
static unsigned int ng3[] = {8U, 0U};
static unsigned int ng4[] = {7U, 0U};
static unsigned int ng5[] = {2U, 0U};
static unsigned int ng6[] = {9U, 0U};
static unsigned int ng7[] = {3U, 0U};
static unsigned int ng8[] = {0U, 0U};



static void Cont_14_0(char *t0)
{
    char t3[8];
    char t4[8];
    char t6[8];
    char t22[8];
    char t36[8];
    char t52[8];
    char t60[8];
    char t108[8];
    char t109[8];
    char t112[8];
    char t128[8];
    char t143[8];
    char t159[8];
    char t167[8];
    char t211[8];
    char t212[8];
    char t215[8];
    char *t1;
    char *t2;
    char *t5;
    char *t7;
    char *t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    char *t21;
    char *t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    char *t29;
    char *t30;
    unsigned int t31;
    unsigned int t32;
    unsigned int t33;
    char *t34;
    char *t35;
    char *t37;
    char *t38;
    unsigned int t39;
    unsigned int t40;
    unsigned int t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;
    unsigned int t45;
    unsigned int t46;
    unsigned int t47;
    unsigned int t48;
    unsigned int t49;
    unsigned int t50;
    char *t51;
    char *t53;
    unsigned int t54;
    unsigned int t55;
    unsigned int t56;
    unsigned int t57;
    unsigned int t58;
    char *t59;
    unsigned int t61;
    unsigned int t62;
    unsigned int t63;
    char *t64;
    char *t65;
    char *t66;
    unsigned int t67;
    unsigned int t68;
    unsigned int t69;
    unsigned int t70;
    unsigned int t71;
    unsigned int t72;
    unsigned int t73;
    char *t74;
    char *t75;
    unsigned int t76;
    unsigned int t77;
    unsigned int t78;
    unsigned int t79;
    unsigned int t80;
    unsigned int t81;
    unsigned int t82;
    unsigned int t83;
    int t84;
    int t85;
    unsigned int t86;
    unsigned int t87;
    unsigned int t88;
    unsigned int t89;
    unsigned int t90;
    unsigned int t91;
    char *t92;
    unsigned int t93;
    unsigned int t94;
    unsigned int t95;
    unsigned int t96;
    unsigned int t97;
    char *t98;
    char *t99;
    unsigned int t100;
    unsigned int t101;
    unsigned int t102;
    char *t103;
    unsigned int t104;
    unsigned int t105;
    unsigned int t106;
    unsigned int t107;
    char *t110;
    char *t111;
    char *t113;
    char *t114;
    unsigned int t115;
    unsigned int t116;
    unsigned int t117;
    unsigned int t118;
    unsigned int t119;
    unsigned int t120;
    unsigned int t121;
    unsigned int t122;
    unsigned int t123;
    unsigned int t124;
    unsigned int t125;
    unsigned int t126;
    char *t127;
    char *t129;
    unsigned int t130;
    unsigned int t131;
    unsigned int t132;
    unsigned int t133;
    unsigned int t134;
    char *t135;
    char *t136;
    unsigned int t137;
    unsigned int t138;
    unsigned int t139;
    unsigned int t140;
    char *t141;
    char *t142;
    char *t144;
    char *t145;
    unsigned int t146;
    unsigned int t147;
    unsigned int t148;
    unsigned int t149;
    unsigned int t150;
    unsigned int t151;
    unsigned int t152;
    unsigned int t153;
    unsigned int t154;
    unsigned int t155;
    unsigned int t156;
    unsigned int t157;
    char *t158;
    char *t160;
    unsigned int t161;
    unsigned int t162;
    unsigned int t163;
    unsigned int t164;
    unsigned int t165;
    char *t166;
    unsigned int t168;
    unsigned int t169;
    unsigned int t170;
    char *t171;
    char *t172;
    char *t173;
    unsigned int t174;
    unsigned int t175;
    unsigned int t176;
    unsigned int t177;
    unsigned int t178;
    unsigned int t179;
    unsigned int t180;
    char *t181;
    char *t182;
    unsigned int t183;
    unsigned int t184;
    unsigned int t185;
    int t186;
    unsigned int t187;
    unsigned int t188;
    unsigned int t189;
    int t190;
    unsigned int t191;
    unsigned int t192;
    unsigned int t193;
    unsigned int t194;
    char *t195;
    unsigned int t196;
    unsigned int t197;
    unsigned int t198;
    unsigned int t199;
    unsigned int t200;
    char *t201;
    char *t202;
    unsigned int t203;
    unsigned int t204;
    unsigned int t205;
    char *t206;
    unsigned int t207;
    unsigned int t208;
    unsigned int t209;
    unsigned int t210;
    char *t213;
    char *t214;
    char *t216;
    char *t217;
    unsigned int t218;
    unsigned int t219;
    unsigned int t220;
    unsigned int t221;
    unsigned int t222;
    unsigned int t223;
    unsigned int t224;
    unsigned int t225;
    unsigned int t226;
    unsigned int t227;
    unsigned int t228;
    unsigned int t229;
    char *t230;
    char *t231;
    unsigned int t232;
    unsigned int t233;
    unsigned int t234;
    unsigned int t235;
    unsigned int t236;
    char *t237;
    char *t238;
    unsigned int t239;
    unsigned int t240;
    unsigned int t241;
    char *t242;
    unsigned int t243;
    unsigned int t244;
    unsigned int t245;
    unsigned int t246;
    char *t247;
    char *t248;
    char *t249;
    char *t250;
    char *t251;
    char *t252;
    unsigned int t253;
    unsigned int t254;
    char *t255;
    unsigned int t256;
    unsigned int t257;
    char *t258;
    unsigned int t259;
    unsigned int t260;
    char *t261;

LAB0:    t1 = (t0 + 2688U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(14, ng0);
    t2 = (t0 + 1528U);
    t5 = *((char **)t2);
    t2 = ((char*)((ng1)));
    memset(t6, 0, 8);
    t7 = (t5 + 4);
    t8 = (t2 + 4);
    t9 = *((unsigned int *)t5);
    t10 = *((unsigned int *)t2);
    t11 = (t9 ^ t10);
    t12 = *((unsigned int *)t7);
    t13 = *((unsigned int *)t8);
    t14 = (t12 ^ t13);
    t15 = (t11 | t14);
    t16 = *((unsigned int *)t7);
    t17 = *((unsigned int *)t8);
    t18 = (t16 | t17);
    t19 = (~(t18));
    t20 = (t15 & t19);
    if (t20 != 0)
        goto LAB7;

LAB4:    if (t18 != 0)
        goto LAB6;

LAB5:    *((unsigned int *)t6) = 1;

LAB7:    memset(t22, 0, 8);
    t23 = (t6 + 4);
    t24 = *((unsigned int *)t23);
    t25 = (~(t24));
    t26 = *((unsigned int *)t6);
    t27 = (t26 & t25);
    t28 = (t27 & 1U);
    if (t28 != 0)
        goto LAB8;

LAB9:    if (*((unsigned int *)t23) != 0)
        goto LAB10;

LAB11:    t30 = (t22 + 4);
    t31 = *((unsigned int *)t22);
    t32 = *((unsigned int *)t30);
    t33 = (t31 || t32);
    if (t33 > 0)
        goto LAB12;

LAB13:    memcpy(t60, t22, 8);

LAB14:    memset(t4, 0, 8);
    t92 = (t60 + 4);
    t93 = *((unsigned int *)t92);
    t94 = (~(t93));
    t95 = *((unsigned int *)t60);
    t96 = (t95 & t94);
    t97 = (t96 & 1U);
    if (t97 != 0)
        goto LAB26;

LAB27:    if (*((unsigned int *)t92) != 0)
        goto LAB28;

LAB29:    t99 = (t4 + 4);
    t100 = *((unsigned int *)t4);
    t101 = *((unsigned int *)t99);
    t102 = (t100 || t101);
    if (t102 > 0)
        goto LAB30;

LAB31:    t104 = *((unsigned int *)t4);
    t105 = (~(t104));
    t106 = *((unsigned int *)t99);
    t107 = (t105 || t106);
    if (t107 > 0)
        goto LAB32;

LAB33:    if (*((unsigned int *)t99) > 0)
        goto LAB34;

LAB35:    if (*((unsigned int *)t4) > 0)
        goto LAB36;

LAB37:    memcpy(t3, t108, 8);

LAB38:    t248 = (t0 + 3088);
    t249 = (t248 + 56U);
    t250 = *((char **)t249);
    t251 = (t250 + 56U);
    t252 = *((char **)t251);
    memset(t252, 0, 8);
    t253 = 7U;
    t254 = t253;
    t255 = (t3 + 4);
    t256 = *((unsigned int *)t3);
    t253 = (t253 & t256);
    t257 = *((unsigned int *)t255);
    t254 = (t254 & t257);
    t258 = (t252 + 4);
    t259 = *((unsigned int *)t252);
    *((unsigned int *)t252) = (t259 | t253);
    t260 = *((unsigned int *)t258);
    *((unsigned int *)t258) = (t260 | t254);
    xsi_driver_vfirst_trans(t248, 0, 2);
    t261 = (t0 + 3008);
    *((int *)t261) = 1;

LAB1:    return;
LAB6:    t21 = (t6 + 4);
    *((unsigned int *)t6) = 1;
    *((unsigned int *)t21) = 1;
    goto LAB7;

LAB8:    *((unsigned int *)t22) = 1;
    goto LAB11;

LAB10:    t29 = (t22 + 4);
    *((unsigned int *)t22) = 1;
    *((unsigned int *)t29) = 1;
    goto LAB11;

LAB12:    t34 = (t0 + 1208U);
    t35 = *((char **)t34);
    t34 = ((char*)((ng2)));
    memset(t36, 0, 8);
    t37 = (t35 + 4);
    t38 = (t34 + 4);
    t39 = *((unsigned int *)t35);
    t40 = *((unsigned int *)t34);
    t41 = (t39 ^ t40);
    t42 = *((unsigned int *)t37);
    t43 = *((unsigned int *)t38);
    t44 = (t42 ^ t43);
    t45 = (t41 | t44);
    t46 = *((unsigned int *)t37);
    t47 = *((unsigned int *)t38);
    t48 = (t46 | t47);
    t49 = (~(t48));
    t50 = (t45 & t49);
    if (t50 != 0)
        goto LAB18;

LAB15:    if (t48 != 0)
        goto LAB17;

LAB16:    *((unsigned int *)t36) = 1;

LAB18:    memset(t52, 0, 8);
    t53 = (t36 + 4);
    t54 = *((unsigned int *)t53);
    t55 = (~(t54));
    t56 = *((unsigned int *)t36);
    t57 = (t56 & t55);
    t58 = (t57 & 1U);
    if (t58 != 0)
        goto LAB19;

LAB20:    if (*((unsigned int *)t53) != 0)
        goto LAB21;

LAB22:    t61 = *((unsigned int *)t22);
    t62 = *((unsigned int *)t52);
    t63 = (t61 & t62);
    *((unsigned int *)t60) = t63;
    t64 = (t22 + 4);
    t65 = (t52 + 4);
    t66 = (t60 + 4);
    t67 = *((unsigned int *)t64);
    t68 = *((unsigned int *)t65);
    t69 = (t67 | t68);
    *((unsigned int *)t66) = t69;
    t70 = *((unsigned int *)t66);
    t71 = (t70 != 0);
    if (t71 == 1)
        goto LAB23;

LAB24:
LAB25:    goto LAB14;

LAB17:    t51 = (t36 + 4);
    *((unsigned int *)t36) = 1;
    *((unsigned int *)t51) = 1;
    goto LAB18;

LAB19:    *((unsigned int *)t52) = 1;
    goto LAB22;

LAB21:    t59 = (t52 + 4);
    *((unsigned int *)t52) = 1;
    *((unsigned int *)t59) = 1;
    goto LAB22;

LAB23:    t72 = *((unsigned int *)t60);
    t73 = *((unsigned int *)t66);
    *((unsigned int *)t60) = (t72 | t73);
    t74 = (t22 + 4);
    t75 = (t52 + 4);
    t76 = *((unsigned int *)t22);
    t77 = (~(t76));
    t78 = *((unsigned int *)t74);
    t79 = (~(t78));
    t80 = *((unsigned int *)t52);
    t81 = (~(t80));
    t82 = *((unsigned int *)t75);
    t83 = (~(t82));
    t84 = (t77 & t79);
    t85 = (t81 & t83);
    t86 = (~(t84));
    t87 = (~(t85));
    t88 = *((unsigned int *)t66);
    *((unsigned int *)t66) = (t88 & t86);
    t89 = *((unsigned int *)t66);
    *((unsigned int *)t66) = (t89 & t87);
    t90 = *((unsigned int *)t60);
    *((unsigned int *)t60) = (t90 & t86);
    t91 = *((unsigned int *)t60);
    *((unsigned int *)t60) = (t91 & t87);
    goto LAB25;

LAB26:    *((unsigned int *)t4) = 1;
    goto LAB29;

LAB28:    t98 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t98) = 1;
    goto LAB29;

LAB30:    t103 = ((char*)((ng2)));
    goto LAB31;

LAB32:    t110 = (t0 + 1528U);
    t111 = *((char **)t110);
    t110 = ((char*)((ng3)));
    memset(t112, 0, 8);
    t113 = (t111 + 4);
    t114 = (t110 + 4);
    t115 = *((unsigned int *)t111);
    t116 = *((unsigned int *)t110);
    t117 = (t115 ^ t116);
    t118 = *((unsigned int *)t113);
    t119 = *((unsigned int *)t114);
    t120 = (t118 ^ t119);
    t121 = (t117 | t120);
    t122 = *((unsigned int *)t113);
    t123 = *((unsigned int *)t114);
    t124 = (t122 | t123);
    t125 = (~(t124));
    t126 = (t121 & t125);
    if (t126 != 0)
        goto LAB42;

LAB39:    if (t124 != 0)
        goto LAB41;

LAB40:    *((unsigned int *)t112) = 1;

LAB42:    memset(t128, 0, 8);
    t129 = (t112 + 4);
    t130 = *((unsigned int *)t129);
    t131 = (~(t130));
    t132 = *((unsigned int *)t112);
    t133 = (t132 & t131);
    t134 = (t133 & 1U);
    if (t134 != 0)
        goto LAB43;

LAB44:    if (*((unsigned int *)t129) != 0)
        goto LAB45;

LAB46:    t136 = (t128 + 4);
    t137 = *((unsigned int *)t128);
    t138 = (!(t137));
    t139 = *((unsigned int *)t136);
    t140 = (t138 || t139);
    if (t140 > 0)
        goto LAB47;

LAB48:    memcpy(t167, t128, 8);

LAB49:    memset(t109, 0, 8);
    t195 = (t167 + 4);
    t196 = *((unsigned int *)t195);
    t197 = (~(t196));
    t198 = *((unsigned int *)t167);
    t199 = (t198 & t197);
    t200 = (t199 & 1U);
    if (t200 != 0)
        goto LAB61;

LAB62:    if (*((unsigned int *)t195) != 0)
        goto LAB63;

LAB64:    t202 = (t109 + 4);
    t203 = *((unsigned int *)t109);
    t204 = *((unsigned int *)t202);
    t205 = (t203 || t204);
    if (t205 > 0)
        goto LAB65;

LAB66:    t207 = *((unsigned int *)t109);
    t208 = (~(t207));
    t209 = *((unsigned int *)t202);
    t210 = (t208 || t209);
    if (t210 > 0)
        goto LAB67;

LAB68:    if (*((unsigned int *)t202) > 0)
        goto LAB69;

LAB70:    if (*((unsigned int *)t109) > 0)
        goto LAB71;

LAB72:    memcpy(t108, t211, 8);

LAB73:    goto LAB33;

LAB34:    xsi_vlog_unsigned_bit_combine(t3, 3, t103, 3, t108, 3);
    goto LAB38;

LAB36:    memcpy(t3, t103, 8);
    goto LAB38;

LAB41:    t127 = (t112 + 4);
    *((unsigned int *)t112) = 1;
    *((unsigned int *)t127) = 1;
    goto LAB42;

LAB43:    *((unsigned int *)t128) = 1;
    goto LAB46;

LAB45:    t135 = (t128 + 4);
    *((unsigned int *)t128) = 1;
    *((unsigned int *)t135) = 1;
    goto LAB46;

LAB47:    t141 = (t0 + 1528U);
    t142 = *((char **)t141);
    t141 = ((char*)((ng4)));
    memset(t143, 0, 8);
    t144 = (t142 + 4);
    t145 = (t141 + 4);
    t146 = *((unsigned int *)t142);
    t147 = *((unsigned int *)t141);
    t148 = (t146 ^ t147);
    t149 = *((unsigned int *)t144);
    t150 = *((unsigned int *)t145);
    t151 = (t149 ^ t150);
    t152 = (t148 | t151);
    t153 = *((unsigned int *)t144);
    t154 = *((unsigned int *)t145);
    t155 = (t153 | t154);
    t156 = (~(t155));
    t157 = (t152 & t156);
    if (t157 != 0)
        goto LAB53;

LAB50:    if (t155 != 0)
        goto LAB52;

LAB51:    *((unsigned int *)t143) = 1;

LAB53:    memset(t159, 0, 8);
    t160 = (t143 + 4);
    t161 = *((unsigned int *)t160);
    t162 = (~(t161));
    t163 = *((unsigned int *)t143);
    t164 = (t163 & t162);
    t165 = (t164 & 1U);
    if (t165 != 0)
        goto LAB54;

LAB55:    if (*((unsigned int *)t160) != 0)
        goto LAB56;

LAB57:    t168 = *((unsigned int *)t128);
    t169 = *((unsigned int *)t159);
    t170 = (t168 | t169);
    *((unsigned int *)t167) = t170;
    t171 = (t128 + 4);
    t172 = (t159 + 4);
    t173 = (t167 + 4);
    t174 = *((unsigned int *)t171);
    t175 = *((unsigned int *)t172);
    t176 = (t174 | t175);
    *((unsigned int *)t173) = t176;
    t177 = *((unsigned int *)t173);
    t178 = (t177 != 0);
    if (t178 == 1)
        goto LAB58;

LAB59:
LAB60:    goto LAB49;

LAB52:    t158 = (t143 + 4);
    *((unsigned int *)t143) = 1;
    *((unsigned int *)t158) = 1;
    goto LAB53;

LAB54:    *((unsigned int *)t159) = 1;
    goto LAB57;

LAB56:    t166 = (t159 + 4);
    *((unsigned int *)t159) = 1;
    *((unsigned int *)t166) = 1;
    goto LAB57;

LAB58:    t179 = *((unsigned int *)t167);
    t180 = *((unsigned int *)t173);
    *((unsigned int *)t167) = (t179 | t180);
    t181 = (t128 + 4);
    t182 = (t159 + 4);
    t183 = *((unsigned int *)t181);
    t184 = (~(t183));
    t185 = *((unsigned int *)t128);
    t186 = (t185 & t184);
    t187 = *((unsigned int *)t182);
    t188 = (~(t187));
    t189 = *((unsigned int *)t159);
    t190 = (t189 & t188);
    t191 = (~(t186));
    t192 = (~(t190));
    t193 = *((unsigned int *)t173);
    *((unsigned int *)t173) = (t193 & t191);
    t194 = *((unsigned int *)t173);
    *((unsigned int *)t173) = (t194 & t192);
    goto LAB60;

LAB61:    *((unsigned int *)t109) = 1;
    goto LAB64;

LAB63:    t201 = (t109 + 4);
    *((unsigned int *)t109) = 1;
    *((unsigned int *)t201) = 1;
    goto LAB64;

LAB65:    t206 = ((char*)((ng5)));
    goto LAB66;

LAB67:    t213 = (t0 + 1528U);
    t214 = *((char **)t213);
    t213 = ((char*)((ng6)));
    memset(t215, 0, 8);
    t216 = (t214 + 4);
    t217 = (t213 + 4);
    t218 = *((unsigned int *)t214);
    t219 = *((unsigned int *)t213);
    t220 = (t218 ^ t219);
    t221 = *((unsigned int *)t216);
    t222 = *((unsigned int *)t217);
    t223 = (t221 ^ t222);
    t224 = (t220 | t223);
    t225 = *((unsigned int *)t216);
    t226 = *((unsigned int *)t217);
    t227 = (t225 | t226);
    t228 = (~(t227));
    t229 = (t224 & t228);
    if (t229 != 0)
        goto LAB77;

LAB74:    if (t227 != 0)
        goto LAB76;

LAB75:    *((unsigned int *)t215) = 1;

LAB77:    memset(t212, 0, 8);
    t231 = (t215 + 4);
    t232 = *((unsigned int *)t231);
    t233 = (~(t232));
    t234 = *((unsigned int *)t215);
    t235 = (t234 & t233);
    t236 = (t235 & 1U);
    if (t236 != 0)
        goto LAB78;

LAB79:    if (*((unsigned int *)t231) != 0)
        goto LAB80;

LAB81:    t238 = (t212 + 4);
    t239 = *((unsigned int *)t212);
    t240 = *((unsigned int *)t238);
    t241 = (t239 || t240);
    if (t241 > 0)
        goto LAB82;

LAB83:    t243 = *((unsigned int *)t212);
    t244 = (~(t243));
    t245 = *((unsigned int *)t238);
    t246 = (t244 || t245);
    if (t246 > 0)
        goto LAB84;

LAB85:    if (*((unsigned int *)t238) > 0)
        goto LAB86;

LAB87:    if (*((unsigned int *)t212) > 0)
        goto LAB88;

LAB89:    memcpy(t211, t247, 8);

LAB90:    goto LAB68;

LAB69:    xsi_vlog_unsigned_bit_combine(t108, 3, t206, 3, t211, 3);
    goto LAB73;

LAB71:    memcpy(t108, t206, 8);
    goto LAB73;

LAB76:    t230 = (t215 + 4);
    *((unsigned int *)t215) = 1;
    *((unsigned int *)t230) = 1;
    goto LAB77;

LAB78:    *((unsigned int *)t212) = 1;
    goto LAB81;

LAB80:    t237 = (t212 + 4);
    *((unsigned int *)t212) = 1;
    *((unsigned int *)t237) = 1;
    goto LAB81;

LAB82:    t242 = ((char*)((ng7)));
    goto LAB83;

LAB84:    t247 = ((char*)((ng8)));
    goto LAB85;

LAB86:    xsi_vlog_unsigned_bit_combine(t211, 3, t242, 3, t247, 3);
    goto LAB90;

LAB88:    memcpy(t211, t242, 8);
    goto LAB90;

}


extern void work_m_00000000001414238066_1293135620_init()
{
	static char *pe[] = {(void *)Cont_14_0};
	xsi_register_didat("work_m_00000000001414238066_1293135620", "isim/mips_tb_isim_beh.exe.sim/work/m_00000000001414238066_1293135620.didat");
	xsi_register_executes(pe);
}
